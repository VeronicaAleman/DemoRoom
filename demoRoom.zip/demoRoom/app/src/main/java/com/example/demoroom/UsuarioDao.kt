package com.example.demoroom

package ni.edu.uca.pruebabd.usuario
import androidx.room.*
interface UsuarioDao {
    @Dao
    interface UsuarioDao {
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun insert(usuario: UsuarioEntity)

        @Query("SELECT * FROM TblUsuarios")
        suspend fun getAll(): List<UsuarioEntity>

        @Update
        fun update(usuario: UsuarioEntity)

        @Delete
        fun delete(usuario: UsuarioEntity)
    }
}