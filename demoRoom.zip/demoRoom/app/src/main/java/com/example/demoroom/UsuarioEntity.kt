package com.example.demoroom

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName="TblUsuarios")
data class UsuarioEntity(
@PrimaryKey(autoGenerate = false)
val idUsuario:String,
@ColumnInfo(name = "passUsuario")
val passUsuario: String,
@ColumnInfo(name = "email")
val email: String,
@ColumnInfo(name = "nombres")
val nombres: String,
@ColumnInfo(name = "apellidos")
val apellidos:String
)
